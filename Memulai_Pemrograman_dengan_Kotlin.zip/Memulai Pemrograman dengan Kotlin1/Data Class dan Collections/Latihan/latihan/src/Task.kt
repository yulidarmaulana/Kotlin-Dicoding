fun main() {

    // TODO 1
    val vehicle = "Vehicle"

    // TODO 2
    val type = "Motorcycle"
    val maxSpeed = "230Km/s"
    val maxTank = "10Ltr"

    // TODO 3
    println("$vehicle")
    println("Type: $type" )
    println("Maximal Speed: $maxSpeed")
    println("Maximal Tank: $maxTank")
}